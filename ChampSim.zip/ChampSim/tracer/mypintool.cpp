#include "pin.H"

VOID PIN_FUNCALL(main()) {
  // Get the address of the `main()` function.
  ADDRINT main_addr = PIN_GetFunctionAddress(PIN_FUNC_NAME(main));

  // Iterate over all of the instructions in the `main()` function.
  for (ADDRINT addr = main_addr; addr != 0; addr = PIN_GetNextInstruction(addr)) {
    // Print out the address of the instruction.
    printf("Instruction address: 0x%x\n", addr);
  }
}

int main(int argc, char *argv[]) {
  // Initialize Pintool.
  PIN_Init(argc, argv);

  // Register the `PIN_FUNCALL(main())` function with Pintool.
  PIN_RegisterFunctionCall(PIN_FUNC_NAME(main), PIN_FUNCALL(main));

  // Run the program.
  PIN_StartProgram();

  // Uninitialize Pintool.
  PIN_FinishProgram();

  return 0;
}
